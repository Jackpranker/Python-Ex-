"""OUsman Jack"""
First_Name_list=[]
Last_Name_list=[]
Full_Name_list=[]
Email_list=[]
First_Name= input("Please Enter your first Name \n")
Last_Name= input("Please Enter your last Name \n ")
Full_Name= First_Name + "" + Last_Name
Email= Full_Name + "@xyz.com"
mail= Email.lower()

print(First_Name.lower(), Last_Name.lower(), Full_Name.upper(), Email.lower() )
print("u have to type Quick 2-time for the program to abort")

stop ="Quick"
while First_Name != "Quick":
     First_Name= input("Please Enter your first Name \n ")
     First_Name_list.append(First_Name)
     Last_Name= input("Please Enter your last Name \n ")
     Last_Name_list.append(Last_Name)
     Full_Name_list.append(Full_Name)
     Full_Name= First_Name + Last_Name
     Email= Full_Name +  "@xyz.com" 
     Email_list.append(Email)
     Details= First_Name.lower()+ " "+ Last_Name.lower()+" "+ Full_Name.upper()+" "+ Email.lower()
     print(Details)
    
else:
    print(First_Name_list,Last_Name_list,Full_Name_list,Email_list)
    print("Welcome to the search and updates part")
    updates=str(input("Type Yes or no \n "))                
    if updates== "Yes":
        print("")
        add=[]
        Erase=[]
        Details.replace(add)
        Details.remove(Erase)
        print(add,Erase)
    print("Thank you for using my Program")