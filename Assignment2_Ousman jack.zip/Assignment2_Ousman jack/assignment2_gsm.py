"""Ousman Jack"""
number= str(input('hello user enter your number \n'))

if str(number).startswith(('7','2','+2207','+2202','002202','002207')):
    print(f"Hello User the Number u entered {number } is Africell")
else:
      
    if str(number).startswith(('3','5','+2203','+2205','002203','002205')):
         print(f"Hello User the Number u entered {number } is Qcell")
    else:
            
        if str(number).startswith(('9','+2209','002209')):
             print(f"Hello User the Number u entered {number } is Gamcel")
        else:
            
            if str(number).startswith(('6','+2206','002206')):
                print(f"Hello User the Number u entered {number } is Comium")
            else:
                    if str(number).startswith(('1','8','4')):
                         print(f"Hello User the Number u entered {number } is not valid Gambia Gsm number")
