print('=========================================================')
print('LIST OPERATION : MAIN MENU')
print('=========================================================')

print('1. Add new data element to the list')
print('2. Read data elements from a text file')
print('3. Delete a dat from te list')
print('4. sort data elements in the list')
print('5. Display all data elements on standard output')
print('6. Write data elements to a text file')
print('7. Exit')


import sys
Information=sys.stdout
Data=['Java','C++','SQL','HTML']

def Adding_element():
    Information=open('Data.txt','a')
    add_data= input('Add a new data to the information:  ')
    Data.append(add_data)
    print(f'A {add_data} has been added ')
    Information.write(str(Data)+ '\n')
    print('Data written to a file completed')
    sys.stdout.write(str(Data)+ '\n')
    print('Standard output printed')
    
def Read_Element():
    Information=open('Data.txt','r')
    print(Information.readlines())
    print('Read element(s) comfirm')
    sys.stdout.write(str(Data)+ '\n')
    print('Standard output printed')
    
def Delete_element():
    Information=open('Data.txt','r+')
    print(Data)
    Revome_data= str (input('Revome an information:  '))
    Data.remove(Revome_data)
    print(f'{Revome_data} has been remove')
    Information.write(Revome_data)
    print('Data written to a file completed')
    sys.stdout.write(str(Data)+ '\n')
    print('Standard output printed')

def Sorts_Elements():
    Information=open('Data.txt','r+')
    Data_sort=sorted(Data, reverse=False)
    print('Data sorted ')
    sys.stdout.write(str(Data_sort) + '\n')
    print('Standard output printed')
    Information.write(str(Data_sort))
    print('Data written to a file completed')

def exit_command():
    sys.exit()
    print('Test d exit command')
    
def menu():
    print('*****Program Start*****')
    Adding_element()
    Read_Element()
    Delete_element()
    Sorts_Elements()
    exit_command()
    print('*****Program Ends*****')

menu()





